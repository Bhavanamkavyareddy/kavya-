/**
 * Simple file-based store using JSON files.
 * Synchronous operations for simplicity - fine for demo/small projects.
 */

const fs = require('fs');
const path = require('path');

const PRODUCTS_FILE = path.join(__dirname, 'products.json');
const ORDERS_FILE = path.join(__dirname, 'orders.json');

function readJson(file, defaultValue) {
  try {
    const txt = fs.readFileSync(file, 'utf8');
    return JSON.parse(txt || 'null') || defaultValue;
  } catch (e) {
    return defaultValue;
  }
}

function writeJson(file, obj) {
  fs.writeFileSync(file, JSON.stringify(obj, null, 2), 'utf8');
}

// Ensure files exist
if (!fs.existsSync(PRODUCTS_FILE)) writeJson(PRODUCTS_FILE, []);
if (!fs.existsSync(ORDERS_FILE)) writeJson(ORDERS_FILE, []);

module.exports = {
  getProducts() {
    return readJson(PRODUCTS_FILE, []);
  },
  getProduct(id) {
    const products = readJson(PRODUCTS_FILE, []);
    return products.find(p => p.id === id);
  },
  addProduct(p) {
    const products = readJson(PRODUCTS_FILE, []);
    products.push(p);
    writeJson(PRODUCTS_FILE, products);
  },
  getOrders() {
    return readJson(ORDERS_FILE, []);
  },
  getOrder(id) {
    const orders = readJson(ORDERS_FILE, []);
    return orders.find(o => o.id === id);
  },
  addOrder(order) {
    const orders = readJson(ORDERS_FILE, []);
    orders.push(order);
    writeJson(ORDERS_FILE, orders);
  },
  updateOrderStatus(id, status) {
    const orders = readJson(ORDERS_FILE, []);
    const idx = orders.findIndex(o => o.id === id);
    if (idx === -1) return null;
    orders[idx].status = status;
    orders[idx].updatedAt = new Date().toISOString();
    writeJson(ORDERS_FILE, orders);
    return orders[idx];
  }
};
