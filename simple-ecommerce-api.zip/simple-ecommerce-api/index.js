/**
 * Simple E-commerce API (file-based JSON store)
 * Run: npm install
 *      npm start
 *
 * Endpoints:
 *  GET  /products                 -> list products
 *  GET  /products/:id             -> get product
 *  POST /orders                   -> create order
 *  GET  /orders                   -> list orders
 *  GET  /orders/:id               -> get order
 *  PUT  /orders/:id/status        -> update order status (body: { status })
 *
 * Data is stored in /data/products.json and /data/orders.json
 */

const express = require('express');
const bodyParser = require('body-parser');
const { v4: uuidv4 } = require('uuid');
const store = require('./data/store');

const app = express();
const PORT = process.env.PORT || 3000;

app.use(bodyParser.json());

// PRODUCTS
app.get('/products', (req, res) => {
  const products = store.getProducts();
  res.json(products);
});

app.get('/products/:id', (req, res) => {
  const p = store.getProduct(req.params.id);
  if (!p) return res.status(404).json({ error: 'Product not found' });
  res.json(p);
});

// ORDERS
app.post('/orders', (req, res) => {
  const { customerName, items } = req.body;
  if (!customerName || !Array.isArray(items) || items.length === 0) {
    return res.status(400).json({ error: 'Invalid order: provide customerName and non-empty items array' });
  }

  // Validate items: { productId, quantity }
  const products = store.getProducts();
  const orderItems = [];
  let total = 0;
  for (const it of items) {
    const prod = products.find(p => p.id === it.productId);
    if (!prod) return res.status(400).json({ error: `Product not found: ${it.productId}` });
    const qty = Number(it.quantity) || 1;
    orderItems.push({ productId: prod.id, name: prod.name, price: prod.price, quantity: qty });
    total += prod.price * qty;
  }

  const order = {
    id: uuidv4(),
    customerName,
    items: orderItems,
    total,
    status: 'pending',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  };

  store.addOrder(order);
  res.status(201).json(order);
});

app.get('/orders', (req, res) => {
  const orders = store.getOrders();
  res.json(orders);
});

app.get('/orders/:id', (req, res) => {
  const order = store.getOrder(req.params.id);
  if (!order) return res.status(404).json({ error: 'Order not found' });
  res.json(order);
});

app.put('/orders/:id/status', (req, res) => {
  const { status } = req.body;
  if (!status) return res.status(400).json({ error: 'Provide status in body' });
  const allowed = ['pending','processing','shipped','delivered','cancelled'];
  if (!allowed.includes(status)) return res.status(400).json({ error: 'Invalid status' });
  const order = store.updateOrderStatus(req.params.id, status);
  if (!order) return res.status(404).json({ error: 'Order not found' });
  res.json(order);
});

app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});
