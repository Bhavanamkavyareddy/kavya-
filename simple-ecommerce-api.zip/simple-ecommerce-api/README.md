# simple-ecommerce-api

A **simple e-commerce API** built with Node.js and Express using a file-based JSON store (no external database).
You can run this in VS CODE.

## Features
- View all products (`GET /products`)
- Get product by id (`GET /products/:id`)
- Create an order (`POST /orders`)
- View all orders (`GET /orders`)
- View single order (`GET /orders/:id`)
- Update order status (`PUT /orders/:id/status`)

## Setup (in VS Code)
1. Open the project folder in VS Code.
2. Install dependencies:
```bash
npm install
```
3. Start the server:
```bash
npm start
```
The server will run at `http://localhost:3000`.

## Example requests

**List products**
```
GET /products
```

**Create order**
```
POST /orders
Content-Type: application/json

{
  "customerName": "Alice",
  "items": [
    { "productId": "p1", "quantity": 2 },
    { "productId": "p3", "quantity": 1 }
  ]
}
```

**Update order status**
```
PUT /orders/<order-id>/status
Content-Type: application/json

{ "status": "shipped" }
```

## Notes
- Data is persisted to `/data/products.json` and `/data/orders.json`.
- This is a small demo project suitable for learning and experimentation.
